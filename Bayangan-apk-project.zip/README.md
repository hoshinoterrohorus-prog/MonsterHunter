# Bayangan (APK)

Game FPS "Perburuan Bayangan" (terkunci horizontal), dibungkus jadi aplikasi Android (WebView). Nama app: **Bayangan**.

## Cara 1 - Android Studio (paling gampang kalau punya laptop)
1. Buka folder ini di Android Studio, tunggu Gradle sync.
2. (Opsional, biar jalan tanpa internet) taruh file `three.min.js` r128 di `app/src/main/assets/`.
   Unduh dari https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
3. Menu Build > Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.

## Cara 2 - GitHub Actions (tanpa install apa pun)
1. Buat repo GitHub baru, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab Actions > Build Bayangan APK > tunggu hijau.
3. Unduh artifact `Bayangan-apk` > ekstrak > `app-debug.apk`, lalu install di HP
   (izinkan "install dari sumber tidak dikenal").

Game: `app/src/main/assets/index.html`. Ganti file itu kalau mau update game.
